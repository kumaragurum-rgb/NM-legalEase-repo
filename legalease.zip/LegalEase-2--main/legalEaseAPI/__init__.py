"""LegalEase API package."""
