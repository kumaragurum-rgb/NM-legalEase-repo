"""
LegalEase backend package.
"""